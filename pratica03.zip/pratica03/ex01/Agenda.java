import java.util.ArrayList;

public class Agenda {
    private ArrayList<Contato> listaContato;

    public Agenda(){
        this.listaContato = new ArrayList<>();
    }

    public ArrayList<Contato> getListaContato(){
        return listaContato;
    }

    public void adicionarContato(Contato contato){
        listaContato.add(contato); //pesquisar como funciona o size 
    }

    public void removerContato(String nomeRemover){
        for (Contato contato : listaContato){
            if (contato.getNome() == nomeRemover){
                listaContato.remove(contato);
                System.out.println("Exclusão bem sucedida. ");
            }
        }
    }

    public void buscarNome(String nomeProcurado){        
        for (Contato contato : listaContato){ 
            if (contato.getNome() == nomeProcurado){ 
                contato.exibirInformacoes();
            } 
            else {
                System.out.println("Usuário não encontrado. ");
            }
        }
    }

    public void buscarEmail(String emailProcurado){
        for (Contato contato : listaContato){
            if (contato.getEmail() == emailProcurado){
                contato.exibirInformacoes();
            }
            else {
                System.out.println("Email não encontrado");
            }
        }
    }

    public void buscarTelefone(String telefoneProcurado){
        for (Contato contato : listaContato){
            if (contato.getTelefone() == telefoneProcurado){
                contato.exibirInformacoes();
            }
            else{
                System.out.println("Telefone não encontrado.");
            }
        }
    }

    public void tamanhoAgenda(){
        int tamanho = listaContato.size();
        System.out.println("Sua agenda possui " + tamanho + " contatos");
    }


    public void listarContato(){
        for (Contato contato: listaContato){
            System.out.println("Nome: " + contato.getNome());
            System.out.println("Email: " + contato.getEmail());
            System.out.println("Telefone: " + contato.getTelefone());
        }
    }
    
}
