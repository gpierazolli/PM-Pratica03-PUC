class ContatoEmergencia extends Contato{
    private int grauPrioridade;

    public ContatoEmergencia(String nome, String email, String telefone, int grauPrioridade){
        super(nome, email, telefone);
        this.grauPrioridade = grauPrioridade;
    }

    public void setGrauPrioridade(int grauPrioridade){
        this.grauPrioridade = grauPrioridade;
    }

    public int getGrauPrioridade(){
        return grauPrioridade;
    }
}
