import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        while (x != 7){

            if (x == 1){ // adicionar contato
                System.out.println("Digite o nome: ");
                String nome = sc.nextLine();
                System.out.println("Digite o email: ");
                String email = sc.nextLine();
                System.out.println("Digite o telefone: ");
                String telefone = sc.nextLine();
                Contato contato = new Contato(nome, email, telefone);
                Agenda agenda = new Agenda();
                agenda.adicionarContato(contato);
            }
            
            else if (x == 2){ // remover contato  
                System.out.println("Digite o nome do contato que voce deseja remover: ");
                String nomeRemover = sc.nextLine();
                Agenda agenda = new Agenda();
                agenda.removerContato(nomeRemover); 
            }

            else if (x == 3){ //buscar contato por nome
                System.out.println("Digite o nome do contato que você deseja encontrar: ");
                String nomeProcurado = sc.nextLine();
                Agenda agenda = new Agenda();
                agenda.buscarNome(nomeProcurado);
            }

            else if (x == 4){ //buscar email
                System.out.println("Digite o email do contato que você deseja encontrar: ");
                String emailProcurado = sc.nextLine();
                Agenda agenda = new Agenda();
                agenda.buscarEmail(emailProcurado);
            }

            else if (x == 5){ //buscar por telefone
                System.out.println("Digite o telefone do contato que você deseja encontrar: ");
                String telefoneProcurado = sc.nextLine();
                Agenda agenda = new Agenda();
                agenda.buscarTelefone(telefoneProcurado);  
            }

            else if (x == 6){ //consultar tamanho da agenda
                Agenda agenda = new Agenda();
                agenda.tamanhoAgenda();
            }

            else{ //para números digitados que não estão dentro do menu 
                System.out.println("Número não está no menu. Tente novamente. ");
            }
            
        }
        sc.close();
    }
    
}
