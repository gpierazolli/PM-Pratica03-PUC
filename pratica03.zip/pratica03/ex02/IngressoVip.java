package ex02;

public abstract class IngressoVip extends Ingresso {
    public String beneficio = "";
    public double acresVip = 0;
    private boolean acessoBackstage;
    private int numeroLounge;
    public IngressoVip (int codigo, String nomeEvento, String setor, double valorBase, boolean acessoBackstage, int numeroLounge){
        super(codigo, nomeEvento, setor, valorBase);
        this.acessoBackstage = acessoBackstage;
        this.numeroLounge = numeroLounge; 
    }

    public void setAcessoBackstage(boolean acessoBackstage){
        this.acessoBackstage = acessoBackstage;
    }

    public boolean getAcessoBackstage(){
        return acessoBackstage;
    }

    public void setNumeroLounge(int numeroLounge){
        this.numeroLounge = numeroLounge;
    }

    public int getNumeroLounge(){
        return numeroLounge; 
    }

    public String obterBeneficio(){
        if (acessoBackstage == true){
            beneficio = "Você possui ingresso Vip com acesso ao Backstage";
        }
        else {
            beneficio = "Você possui ingresso Vip";
        }
        return beneficio;
    }

    @Override 
    public double calcularValorFinal(double valorBase){
        acresVip = valorBase * 1.8;
        System.out.println("O valor do seu ingresso é: " + acresVip);
        if (acessoBackstage == true){
            System.out.println("Você possui acesso ao Backstage");
        }
        return acresVip;
    }


}
