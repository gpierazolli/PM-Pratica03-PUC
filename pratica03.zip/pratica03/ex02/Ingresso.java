package ex02;

public abstract class Ingresso{
    private int codigo;
    private String nomeEvento;
    private String setor;
    private double valorBase;

    public Ingresso(int codigo, String nomeEvento, String setor, double valorBase){
        this.codigo = codigo;
        this.nomeEvento = nomeEvento;
        this.setor = setor;
        this.valorBase = valorBase;
    }

    public void setCodigo(int codigo){
        this.codigo = codigo;
    }

    public void setNomeEvento(String nomeEvento){
        this.nomeEvento = nomeEvento;
    }

    public void setsetor(String setor){
        this.setor = setor;
    }

    public void setValorBase(double valorBase){
        this.valorBase = valorBase;
    }

    public int getCodigo(){
        return codigo;
    }

    public String getNomeEvento(){
        return nomeEvento;
    }

    public String getsetor(){
        return setor;
    }

    public double getValorBase(){
        return valorBase;
    }

    public void informacoesIngresso(){
            System.out.println("Evento: " + nomeEvento);
            System.out.println("Codigo: " + codigo);
            System.out.println("Setor: " + setor);
            System.out.println("Valor: " + valorBase);
    }

    public abstract double calcularValorFinal(double valorBase);
    public abstract String obterBeneficios();
    
}
