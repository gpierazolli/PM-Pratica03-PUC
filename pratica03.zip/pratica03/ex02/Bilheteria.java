package ex02;
import java.util.ArrayList;

public class Bilheteria {
    public double arrecadacaoFinal = 0;
    private ArrayList<Ingresso> listaIngressos;

    public Bilheteria(){
        this.listaIngressos = new ArrayList<>();
    }

    public ArrayList<Ingresso> getListaIngresso(){
        return listaIngressos;
    }
    
    public void adicionarIngresso(Ingresso ingresso){
        listaIngressos.add(ingresso);
    }

    public void removerIngresso(int codigoInformado){
        for (Ingresso ingresso : listaIngressos){
            if (codigoInformado == ingresso.getCodigo()){
                listaIngressos.remove(ingresso);
            }
        }
    }

    public void buscarIngresso(int codigoInformado){
        for (Ingresso ingresso : listaIngressos){
            if (codigoInformado == ingresso.getCodigo()){
                ingresso.informacoesIngresso();
            }
            else{
                System.out.println("Ingresso não cadastrado");
            }
        }
    }
    
    public void listarIngressos() {
        if (listaIngressos.isEmpty()) {
            System.out.println("Nenhum ingresso cadastrado.");
        } 
        else {
            for (Ingresso ingresso : listaIngressos) {
            ingresso.informacoesIngresso();
            }
        }
    }


    public double arrecadacao(){
        arrecadacaoFinal = 0; 

        for (Ingresso ingresso: listaIngressos){
            arrecadacaoFinal += ingresso.calcularValorFinal(ingresso.getValorBase());
        }
        return arrecadacaoFinal;
    }

    public void listarBeneficios(){
        for (Ingresso ingresso : listaIngressos){
            ingresso.obterBeneficios();
        }
    }
}
