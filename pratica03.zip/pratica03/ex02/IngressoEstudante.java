package ex02;

public abstract class IngressoEstudante extends Ingresso{
    public double descontoEst = 0;
    private String instituicaoEnsino; 
    public IngressoEstudante(int codigo, String nomeEvento, String setor, double valorBase, String instituicaoEnsino){
        super(codigo, nomeEvento, setor, valorBase);
        this.instituicaoEnsino = instituicaoEnsino;
    }

    public void setInstituicaoEnsino(String instituicaoEnsino){
        this.instituicaoEnsino = instituicaoEnsino;
    }

    public String getInstituicaoEnsino(){
        return instituicaoEnsino;
    }

    public String obterBeneficio(){
        return "Benefício à meia entrada";
    }

    @Override 
    public double calcularValorFinal(double valorBase){
        System.out.println("Benefício à meia entrada");
        descontoEst = valorBase * 0.5;
        System.out.println("O valor do seu ingresso será: " + descontoEst);
        return descontoEst;
    }
}
