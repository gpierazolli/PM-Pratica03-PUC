package ex02;
import java.util.Scanner;

public class Main {
    public static void main(String [] args){
        Bilheteria bilheteria = new Bilheteria();
        Scanner sc = new Scanner(System.in);
        int x = 0;

        while (x != 7){
        System.out.println(" Digite o numero do serviço desejado: ");
        System.out.println("1 - Cadastrar ingresso");
        System.out.println("2 - Remover ingresso");
        System.out.println("3 - Buscar ingresso por código");
        System.out.println("4 - Listar todos os ingressos");
        System.out.println("5 - Calcular arrecadação total");
        System.out.println("6 - Listar benefícios dos ingressos ");
        System.out.println("7 - Finalizar");
        x = sc.nextInt();
        sc.nextLine();

            if (x == 1){
                System.out.println("Codigo: " );
                int codigo = sc.nextInt();
                sc.nextLine();
                System.out.println("Evento: " );
                String nomeEvento = sc.nextLine();
                System.out.println("Setor: ");
                String setor = sc.nextLine();
                System.out.println("Valor: ");
                double valorBase = sc.nextDouble();
                sc.nextLine();
                Ingresso ingresso = new IngressoComum(codigo, nomeEvento, setor, valorBase);
                bilheteria.adicionarIngresso(ingresso);
            }
            else if (x == 2){
                System.out.println("Digite o codigo do Ingresso que deseja remover: ");
                int codigoInformado = sc.nextInt();
                sc.nextLine();
                bilheteria.removerIngresso(codigoInformado);
            }
            else if (x == 3){
                System.out.println("Digite o codigo do Ingresso que deseja procurar: ");
                int codigoInformado = sc.nextInt();
                sc.nextLine();
                bilheteria.buscarIngresso(codigoInformado); 
            }
            else if (x == 4){
                bilheteria.listarIngressos();
            }
            else if (x == 5){
                System.out.println("O valor final da arrecadação foi de " + bilheteria.arrecadacao());
            }
            else if (x == 6){
                bilheteria.listarBeneficios();
            }
            else{
                System.out.println("Digite um número que corresponda ao menu. ");
            }
        }
    sc.close();
    }
    
}
